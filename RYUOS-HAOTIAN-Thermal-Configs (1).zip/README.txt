# RYUOS HAOTIAN original thermal configuration files

Source: RYUOS_HAOTIAN_OS3.0.309.0.WOBCNXM_CN261005.zip
These are raw, unmodified thermal and power-hint configuration files collected from the ROM logical partitions.
Files: 85; partition counts: {'vendor': 20, 'odm': 25, 'system_ext': 10, 'product': 30}.

Do NOT directly flash, bind-mount or replace vendor/odm config files with these on HyperMOS. Xiaomi stock sconfig numbers can have different meanings from RYU PerfHook mode values.
The artifact does not contain RYU PerfHook executable code, a working kernel governor or any thermal safety bypass.
See manifest.json for each original path and SHA256SUMS.txt.
