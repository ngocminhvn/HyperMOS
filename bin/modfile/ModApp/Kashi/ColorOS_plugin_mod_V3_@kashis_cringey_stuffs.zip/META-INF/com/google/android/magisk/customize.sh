# HEADER PRINT
ui_print "
             __  ___        __  
            /  |/  /__  ___/ /__
           / /|_/ / _ \/ _  (_-<
          /_/  /_/\___/\_,_/___/
            _____         __         
           / ___/__ ___  / /____ ____
          / /__/ -_) _ \/ __/ -_) __/
          \___/\__/_//_/\__/\__/_/   
"
# MODING CHECKS METHODS

verify_and_start_flashing() {
    # Extract Files
    package_extract_dir files "$MODPATH/files"
    add_pkg
}

check_android_version() {

    android_version=$(getprop ro.build.version.release)
if [ "$android_version" -lt 15 ]; then
    abort "
    Android version is not supported.
    "
elif [ "$android_version" -ge 15 ]; then
    ui_print "
    ------------------------------------------
                     READ!!!                  
     Signature verification must be disabled  
         mandatory for mandatory for stock rom and poco users;      
       otherwise, the module will not work.    
    ------------------------------------------
    "
    pluginPath="$MODPATH/files/MIUISystemUIPlugin.apk"
fi

}


add_pkg() {
    PACKAGE_NAME="miui.systemui.plugin"

    ui_print "- Locating SystemUi Plugin Package..."
    pm uninstall-system-updates "$PACKAGE_NAME" 2>/dev/null
    app_path=$(pm path "$PACKAGE_NAME" | sed 's/package://')
    if ! exist "$app_path"; then
        ui_print "- Package not found, adding to a new directory..."
        app_path="/product/app/MIUISystemUIPlugin/MIUISystemUIPlugin.apk"
    fi

    # Ensure the directory for the new app_path exists
    mkdir -p "$(dirname "$MODPATH/system$app_path")"

    app_path="$MODPATH/system$app_path"
    ui_print "- Copying SystemUi Plugin.apk..."
    cp -f "$pluginPath" "$app_path"
    ui_print "- Validating SystemUIPlugin.apk..."
    if ! is_valid "$app_path"; then
        abort "! Validation failed for Plugin"
    fi
}

delete_cache_files() {
    for file in "$1"/*; do
        if [ -f "$file" ]; then
            echo "$file" | grep -qi "plugin" && rm -f "$file"
        elif [ -d "$file" ]; then
            delete_cache_files "$file"
        fi
    done
}

clean_environment() {
    rm -r "$MODPATH/files"
    ui_print " - Cleaning package cache..."
    base_dir="/data/system/package_cache"
    delete_cache_files "$base_dir"
    rm "$MODPATH/customize.sh"
    ui_print "- Done, reboot your device."
}

# MODDING CHECKS CALLS
check_android_version
verify_and_start_flashing

ui_print "
"
# CLEAN THE ENV
clean_environment
