# HEADER PRINT
ui_print "
             __  ___        __  
            /  |/  /__  ___/ /__
           / /|_/ / _ \/ _  (_-<
          /_/  /_/\___/\_,_/___/
            _____         __         
           / ___/__ ___  / /____ ____
          / /__/ -_) _ \/ __/ -_) __/
          \___/\__/_//_/\__/\__/_/   
"
ui_print "
╔══════════════════════════════════╗
║  XIAOMI WAS BUSY COPYING iOS...  ║
║                                  ║
║      SO WE WENT WITH OPPO.       ║
╚══════════════════════════════════╝
"
# MODING CHECKS METHODS

verify_and_start_flashing() {
    # Extract Files
    package_extract_dir files "$MODPATH/files"
    add_pkg
}

check_compatibility_version() {
    hos_version=$(getprop ro.mi.os.version.incremental)
    android_version=$(getprop ro.build.version.release)

    if [[ "$android_version" -lt 15 ]]; then
    abort "Android 15 or above is required. Detected: $android_version"
    fi
    if [[ -z "$hos_version" ]]; then
        hos_version=$(getprop ro.product.build.version.incremental)
    fi
    if [[ "$hos_version" == *OS3* ]]; then
        pluginPath="$MODPATH/files/OS3/MIUISystemUIPlugin.apk"
    elif [[ "$hos_version" == *OS4* ]]; then
        pluginPath="$MODPATH/files/OS4/MIUISystemUIPlugin.apk"
    else
        abort "
    HyperOS version is not supported.
    "
    fi

}

add_pkg() {
    PACKAGE_NAME="miui.systemui.plugin"

    ui_print "- Locating SystemUi Plugin Package..."
    pm uninstall-system-updates "$PACKAGE_NAME" 2>/dev/null
    app_path=$(pm path "$PACKAGE_NAME" | sed 's/package://')
    if ! exist "$app_path"; then
        ui_print "- Package not found, adding to a new directory..."
        app_path="/product/app/MIUISystemUIPlugin/MIUISystemUIPlugin.apk"
    fi

    # Ensure the directory for the new app_path exists
    mkdir -p "$(dirname "$MODPATH/system$app_path")"

    app_path="$MODPATH/system$app_path"
    ui_print "- Copying SystemUi Plugin.apk..."
    cp -f "$pluginPath" "$app_path"
    ui_print "- Validating SystemUIPlugin.apk..."
    if ! is_valid "$app_path"; then
        abort "! Validation failed for Plugin"
    fi
}

delete_cache_files() {
    for file in "$1"/*; do
        if [ -f "$file" ]; then
            echo "$file" | grep -qi "plugin" && rm -f "$file"
        elif [ -d "$file" ]; then
            delete_cache_files "$file"
        fi
    done
}


clean_environment() {
    rm -r "$MODPATH/files"
    base_dir="/data/system/package_cache"
    delete_cache_files "$base_dir"
    rm "$MODPATH/customize.sh"
}

# MODDING CHECKS CALLS
check_compatibility_version
verify_and_start_flashing

ui_print "
"
ui_print "- Done"
ui_print "- Restart Systemui if there's any visual bug"
# CLEAN THE ENV
clean_environment

# --- Mods Center: KernelSU/APatch mount metamodule check ---
[ -f "$MODPATH/kashi_mount_check.sh" ] || unzip -qjo "$ZIPFILE" "META-INF/com/google/android/magisk/kashi_mount_check.sh" -d "$MODPATH" >/dev/null 2>&1
[ -f "$MODPATH/service.sh" ] || unzip -qjo "$ZIPFILE" "META-INF/com/google/android/magisk/service.sh" -d "$MODPATH" >/dev/null 2>&1
chmod 0755 "$MODPATH/service.sh" 2>/dev/null
[ -f "$MODPATH/kashi_mount_check.sh" ] && . "$MODPATH/kashi_mount_check.sh" && kashi_install_check
