#!/system/bin/sh
# kashi AOD v4 rescue: on phones without native full screen AOD, secure full_screen_aod_on=1
# makes miui-services start the display HAL full-AOD path at boot -> bootloop (even after the
# AOD app is removed). Reset it before system_server reads it. The AOD app keeps its own key
# (kashi_full_aod_on), so full screen AOD keeps working in-app.
MODDIR=${0%/*}
[ "$(cat "$MODDIR/kashi_native_fs" 2>/dev/null)" = 1 ] && exit 0
for f in /data/system/users/*/settings_secure.xml; do
    [ -f "$f" ] || continue
    tmp="$MODDIR/.secure.xml"
    if head -c 4 "$f" | grep -q ABX; then
        abx2xml "$f" "$tmp" 2>/dev/null || continue
        abx=1
    else
        cp -f "$f" "$tmp"
        abx=0
    fi
    if grep -q 'name="full_screen_aod_on" value="1"' "$tmp"; then
        cp -af "$f" "$MODDIR/settings_secure.bak"
        sed -i 's/\(name="full_screen_aod_on" value="\)1"/\10"/' "$tmp"
        if [ "$abx" = 1 ]; then xml2abx "$tmp" "$f.kashi" || { rm -f "$tmp" "$f.kashi"; continue; }
        else cp -f "$tmp" "$f.kashi"; fi
        chown system:system "$f.kashi"; chmod 600 "$f.kashi"
        mv -f "$f.kashi" "$f"
        restorecon "$f" 2>/dev/null
        echo "$(date) reset full_screen_aod_on in $f" >> "$MODDIR/kashi_rescue.log"
    fi
    rm -f "$tmp"
done
