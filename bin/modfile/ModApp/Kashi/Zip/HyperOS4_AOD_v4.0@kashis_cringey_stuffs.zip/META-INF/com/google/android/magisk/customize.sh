# Copyright (C) 2025 by ModCenter

ui_print "
             __  ___        __  
            /  |/  /__  ___/ /__
           / /|_/ / _ \/ _  (_-<
          /_/  /_/\___/\_,_/___/
            _____         __         
           / ___/__ ___  / /____ ____
          / /__/ -_) _ \/ __/ -_) __/
          \___/\__/_//_/\__/\__/_/   
"

# ------------------------------------------------------------------ HyperOS 4 detection
# Same checks as the HyperOS 4 Rust launcher module. Ports often keep the base ROM's version props
# (e.g. ro.mi.os.version.name=OS3.0 or no ro.mi.os.version.code at all on a HyperOS 4 port), so the props
# are only one signal; the other is the HyperOS 4 runtime itself.
props_say_os4() {
    for p in ro.mi.os.version.name ro.mi.os.version.incremental ro.build.version.incremental ro.system.build.version.incremental; do
        case "$(getprop $p)" in OS4*|OS\ 4*|V4.*) return 0 ;; esac
    done
    code=$(getprop ro.mi.os.version.code)
    case "$code" in ''|*[!0-9]*) ;; *) [ "$code" -ge 4 ] && return 0 ;; esac
    return 1
}

# HyperOS 3 also has hyos_spawner and libhyper_os_* (older runtime) but not libmisqlite3 /
# librust_maml_sdk: requiring them keeps HyperOS 3 from passing as HyperOS 4.
os4_runtime_present() {
    spawner=""
    for d in /system_ext/bin /system/bin /system/system_ext/bin; do
        [ -e "$d/hyos_spawner" ] && spawner="$d/hyos_spawner"
    done
    [ -n "$spawner" ] || return 1
    for lib in libhyper_os_flutter.so libmisqlite3.so librust_maml_sdk.so libhyper_os_app_public.so \
               libhyper_os_ui_public.so libhyper_os_system_public.so; do
        found=0
        for d in /system_ext/lib64 /system/lib64 /system/system_ext/lib64; do
            [ -e "$d/$lib" ] && found=1
        done
        [ $found = 1 ] || return 1
    done
    return 0
}

# 0 = Vol+, 1 = Vol-, 2 = no key within $1 seconds
volume_key() {
    timeout_s=${1:-15}
    start=$(date +%s)
    while :; do
        ev=$(timeout 1 getevent -lqc 1 2>/dev/null)
        case "$ev" in
            *KEY_VOLUMEUP*DOWN*) return 0 ;;
            *KEY_VOLUMEDOWN*DOWN*) return 1 ;;
        esac
        [ $(( $(date +%s) - start )) -ge "$timeout_s" ] && return 2
    done
}

check_hyperos4() {
    sdk=$(getprop ro.build.version.sdk)
    case "$sdk" in ''|*[!0-9]*) sdk=0 ;; esac
    if [ "$sdk" -lt 35 ]; then
        abort "! Android $(getprop ro.build.version.release) (SDK $sdk) is too old: this AOD app is for HyperOS 4 (Android 15+)."
    fi
    if props_say_os4; then
        ui_print "- HyperOS 4 detected ($(getprop ro.mi.os.version.name))"
        return
    fi
    if os4_runtime_present; then
        ui_print "- HyperOS 4 runtime found (props say: $(getprop ro.mi.os.version.name), common on ports)"
        return
    fi
    ui_print " "
    ui_print "! Could not confirm HyperOS 4:"
    ui_print "  version props: $(getprop ro.mi.os.version.name) / $(getprop ro.build.version.incremental)"
    ui_print "  HyperOS 4 runtime (hyos_spawner, libhyper_os_*, libmisqlite3, librust_maml_sdk): not found"
    ui_print "  This AOD app is the HyperOS 4 one. On other systems it can misbehave."
    ui_print " "
    ui_print "  Vol+ = install anyway      Vol- = cancel      (cancels in 20 s)"
    volume_key 20
    case $? in
        0) ui_print "- Installing anyway (your choice)" ;;
        *) abort "! Cancelled: HyperOS 4 not confirmed" ;;
    esac
}

check_hyperos4
ui_print "
  ------------------------------------------
                   READ!!!                  
   Signature verification must be disabled       
     otherwise, the module will not work.    
  ------------------------------------------
"

# Extract Files (Some Magisk Doesn't have this privilege)
package_extract_dir files "$MODPATH/files"
package_extract_dir system "$MODPATH/system"


# Add MIUIAod App
PACKAGE_NAME="com.miui.aod"

ui_print "- Checking for installed $PACKAGE_NAME updates"
pm uninstall-system-updates "$PACKAGE_NAME" >/dev/null 2>&1

app_path=$(pm path "$PACKAGE_NAME" | sed 's/package://')
if ! exist "$app_path"; then
    ui_print "- Package not found, adding to a new directory..."
    app_path="/product/priv-app/MIUIAod/MIUIAod.apk"

fi
if [[ "$app_path" != "/system/"* ]]; then
    app_path="/system$app_path"
    ui_print "- Prepended /system to app_path: $app_path"
fi
module_app_path="${MODPATH}${app_path}"
pm install -r "$MODPATH/files/MIUIAod.apk" 2>/dev/null
ui_print "- Replacing $PACKAGE_NAME"
mkdir -p "$(dirname "$module_app_path")"
mv -f "$MODPATH/files/MIUIAod.apk" "$module_app_path"
ui_print "- Validating $PACKAGE_NAME"
if ! is_valid "$module_app_path"; then
    abort "! Validation failed for $PACKAGE_NAME"
fi

CPU_ABI=$(getprop ro.product.cpu.abi)

case "$CPU_ABI" in
arm64*) Type=arm64 Libs=arm64-v8a ;;
arm*) Type=arm Libs=armeabi-v7a ;;
x86_64*) Type=x86_64 Libs=x86_64 ;;
x86*) Type=x86 Libs=x86 ;;
esac
LIBS_PATH="$(dirname "$module_app_path")/lib/$Type"
ui_print "- Patching libs"
mkdir -p "$LIBS_PATH"
# Check if the APK contains the expected library directory
if unzip -l "$module_app_path" "lib/$Libs/*" >/dev/null 2>&1; then
    if unzip -o -j "$module_app_path" "lib/$Libs/*" -d "$LIBS_PATH" >/dev/null 2>&1; then
        ui_print "- Libraries Successfully extracted"
    else
        ui_print "! Failed to extract libraries from $PACKAGE_NAME.apk, skipping..."
    fi
else
    ui_print "! No libraries found in $PACKAGE_NAME.apk for $Libs, skipping..."
fi


# Editing Device Features for all devices (kashi v4)
# - support_aod_fullscreen is NOT added any more: miui-services (system_server) reads it together
#   with secure full_screen_aod_on and drives the display HAL full-AOD path -> bootloop that
#   survived removing the apk. The AOD app now unlocks full screen styles by itself.
# - existing keys are replaced instead of appended twice; config_displayBlanksAfterDoze is a
#   framework config and lives in the overlay, not in device_features.
device_codename=$(getprop ro.product.device || getprop ro.boot.product.hardware.sku || getprop ro.boot.hwname)
features_path="$MODPATH/system/product/etc/device_features"
mkdir -p $features_path
native_fs=0
aod_device=0
for device_features in "/product/etc/device_features/"*.xml; do
    [ -f "$device_features" ] || continue
    grep -q 'name="support_aod_fullscreen">true' "$device_features" && native_fs=1
    grep -q 'name="support_aod">true' "$device_features" && aod_device=1
    out="$features_path/$(basename "$device_features")"
    cp -f "$device_features" "$out"
    ui_print "- Editing device features for $device_codename..."
    for key in support_aod support_aod_notification_animate aod_support_keycode_goto_dismiss \
               support_screen_color_persist doze_display_state_supported doze_proximity_check_before_pulse_intent; do
        sed -i "/<bool name=\"$key\">/d" "$out"
        sed -i "/<\/features>/ i\\    <bool name=\"$key\">true</bool>" "$out"
    done
    grep -q '</features>' "$out" || { ui_print "! Error editing device features, skipping..."; rm -f "$out"; }
done
echo "$native_fs" > "$MODPATH/kashi_native_fs"

# Phones that ship without AOD: enable it in the device's own DevicesAndroidOverlay
# (patched on the phone with APKEditor on ART); old overlay only as a fallback.
if [ "$aod_device" = 0 ]; then
    ui_print "- No stock AOD, enabling AOD in DevicesAndroidOverlay..."
    . "$MODPATH/files/kashi_overlay_patch.sh"
    if ! kashi_patch_device_overlay "$MODPATH" "$TMPDIR/kashi_overlay"; then
        ui_print "! Could not patch DevicesAndroidOverlay, using the old AOD overlay"
        overlay_path=$MODPATH/system/product/overlay
        mkdir -p $overlay_path
        cp -f "$MODPATH/files/ElderlyNavigationBarOverlay.apk" $overlay_path
    fi
    rm -rf "$TMPDIR/kashi_overlay"
fi

delete_cache_files() {
    for file in "$1"/*; do
        if [ -f "$file" ]; then
            echo "$file" | grep -Eqi "aod|AOD|Aod" && rm -f "$file"
        elif [ -d "$file" ]; then
            delete_cache_files "$file"
        fi
    done
}

clean_environment() {
    ui_print "- Cleaning package cache..."
    base_dir="/data/system/package_cache"
    delete_cache_files "$base_dir"
    ui_print "- Fixing contexts..."
    set_context /system "$MODPATH/system"
    ui_print "- Done, reboot your device."
    rm -rf "$MODPATH/files"
    rm "$MODPATH/customize.sh"
}
clean_environment

# --- Mods Center: KernelSU/APatch mount metamodule check ---
[ -f "$MODPATH/kashi_mount_check.sh" ] || unzip -qjo "$ZIPFILE" "META-INF/com/google/android/magisk/kashi_mount_check.sh" -d "$MODPATH" >/dev/null 2>&1
[ -f "$MODPATH/service.sh" ] || unzip -qjo "$ZIPFILE" "META-INF/com/google/android/magisk/service.sh" -d "$MODPATH" >/dev/null 2>&1
chmod 0755 "$MODPATH/service.sh" 2>/dev/null
# full_screen_aod_on rescue (resets the setting before system_server reads it on phones without native full AOD)
[ -f "$MODPATH/post-fs-data.sh" ] || unzip -qjo "$ZIPFILE" "META-INF/com/google/android/magisk/post-fs-data.sh" -d "$MODPATH" >/dev/null 2>&1
chmod 0755 "$MODPATH/post-fs-data.sh" 2>/dev/null
[ -f "$MODPATH/kashi_mount_check.sh" ] && . "$MODPATH/kashi_mount_check.sh" && kashi_install_check
