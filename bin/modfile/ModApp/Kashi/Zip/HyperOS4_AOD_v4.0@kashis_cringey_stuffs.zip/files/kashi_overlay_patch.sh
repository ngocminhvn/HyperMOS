# kashi AOD v4: enable AOD in the device's own framework overlay (DevicesAndroidOverlay)
# instead of adding a new overlay that targets "android".
# usage (sourced from customize.sh): kashi_patch_device_overlay <module dir> <work dir>
# returns 0 when $MODPATH/system/product/overlay/DevicesAndroidOverlay.apk was written.
# APKEditor (d8-dexed, files/kashi_apkeditor.jar) runs on the phone's ART (dalvikvm), same as
# the FPS module.

kashi_ov_log() { if command -v ui_print >/dev/null 2>&1; then ui_print "$1"; else echo "$1"; fi; }

kashi_ov_art() {
    _cp="$KOW/classpath.env"
    : > "$_cp"
    if ! /apex/com.android.sdkext/bin/derive_classpath "$_cp" 2>/dev/null || [ ! -s "$_cp" ]; then
        if [ -r /data/system/environ/classpath ]; then
            tr '\0' '\n' < /data/system/environ/classpath > "$_cp" 2>/dev/null
        else
            for _p in $(pidof zygote64 2>/dev/null) $(pidof zygote 2>/dev/null) $(pidof system_server 2>/dev/null); do
                [ -r "/proc/$_p/environ" ] || continue
                tr '\0' '\n' < "/proc/$_p/environ" 2>/dev/null \
                    | sed -n 's/^\(BOOTCLASSPATH\|DEX2OATBOOTCLASSPATH\)=/export \1 /p' > "$_cp"
                [ -s "$_cp" ] && break
            done
        fi
    fi
    while read -r _kw _name _val; do
        [ "$_kw" = export ] && [ -n "$_val" ] && export "$_name=$_val"
    done < "$_cp"
    [ -n "$DEX2OATBOOTCLASSPATH" ] || export DEX2OATBOOTCLASSPATH="$BOOTCLASSPATH"
    export ANDROID_ROOT="${ANDROID_ROOT:-/system}"
    export ANDROID_ART_ROOT="${ANDROID_ART_ROOT:-/apex/com.android.art}"
    export ANDROID_I18N_ROOT="${ANDROID_I18N_ROOT:-/apex/com.android.i18n}"
    export ANDROID_TZDATA_ROOT="${ANDROID_TZDATA_ROOT:-/apex/com.android.tzdata}"
    export ANDROID_DATA="$KOW/art"
    mkdir -p "$ANDROID_DATA/dalvik-cache"
    KDVM=
    for _d in /apex/com.android.art/bin/dalvikvm64 /apex/com.android.art/bin/dalvikvm \
              /system/bin/dalvikvm64 /system/bin/dalvikvm; do
        if [ -x "$_d" ] && "$_d" -Xnoimage-dex2oat -showversion >/dev/null 2>&1; then KDVM="$_d"; break; fi
    done
    [ -n "$KDVM" ]
}

kashi_ov_ae() {
    _out=""; _prev=""
    for _a in "$@"; do [ "$_prev" = "-o" ] && _out="$_a"; _prev="$_a"; done
    _rc=0
    "$KDVM" -Xmx512m -Xnoimage-dex2oat -Djava.io.tmpdir="$KOW" \
        -cp "$KOW/kashi_apkeditor.jar" com.reandroid.apkeditor.Main "$@" >>"$KOW/ae.log" 2>&1 || _rc=$?
    if [ "$_rc" -ge 128 ]; then
        [ -n "$_out" ] && rm -rf "$_out"
        _rc=0
        "$KDVM" -Xint -Xmx512m -Xnoimage-dex2oat -Djava.io.tmpdir="$KOW" \
            -cp "$KOW/kashi_apkeditor.jar" com.reandroid.apkeditor.Main "$@" >>"$KOW/ae.log" 2>&1 || _rc=$?
    fi
    return $_rc
}

# kashi_ov_set <values dir> <bool|string> <name> <value>
kashi_ov_set() {
    _vd="$1"; _t="$2"; _n="$3"; _v="$4"
    _f=$(grep -l "<$_t name=\"$_n\"" "$_vd"/*.xml 2>/dev/null | head -1)
    if [ -n "$_f" ]; then
        sed -i "s#<$_t name=\"$_n\"\([^>]*\)>[^<]*</$_t>#<$_t name=\"$_n\"\1>$_v</$_t>#" "$_f"
        return
    fi
    _f="$_vd/${_t}s.xml"
    [ -f "$_f" ] || printf '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n</resources>\n' > "$_f"
    sed -i "s#</resources>#  <$_t name=\"$_n\">$_v</$_t>\n</resources>#" "$_f"
    # APKEditor only builds entries declared in public.xml: next free id of that type,
    # or a new type id after the highest one when the overlay has no entry of that type yet
    _pub="$_vd/public.xml"
    [ -f "$_pub" ] || return 1
    _id=$(awk -v t="$_t" '
        function hex(h,   i, c, v) {
            v = 0; h = tolower(h)
            for (i = 3; i <= length(h); i++) { c = index("0123456789abcdef", substr(h, i, 1)) - 1; v = v * 16 + c }
            return v
        }
        match($0, /id="0x[0-9a-fA-F]+"/) {
            id = substr($0, RSTART + 4, RLENGTH - 5); v = hex(id)
            ty = int(v / 65536) % 256; e = v % 65536
            if (ty > maxty) maxty = ty
            if ($0 ~ ("type=\"" t "\"")) { has = 1; tt = ty; if (e > me) me = e; seen = 1 }
        }
        END {
            if (has) printf "0x7f%02x%04x", tt, me + 1
            else printf "0x7f%02x0000", maxty + 1
        }' "$_pub")
    sed -i "s#</resources>#  <public id=\"$_id\" type=\"$_t\" name=\"$_n\" />\n</resources>#" "$_pub"
}

kashi_patch_device_overlay() {
    KOM="$1"; KOW="$2"
    _rel=/product/overlay/DevicesAndroidOverlay.apk
    [ -f "$_rel" ] || { kashi_ov_log "! $_rel not found"; return 1; }
    rm -rf "$KOW"; mkdir -p "$KOW"
    cp -f "$KOM/files/kashi_apkeditor.jar" "$KOW/" || return 1
    kashi_ov_art || { kashi_ov_log "! ART runtime not usable"; return 1; }

    # stock copy, also when an older version of this module already overlays it
    _old="/data/adb/modules/miui_aod_mod/system$_rel"
    if [ -f "$_old" ]; then
        unshare -m --propagation private sh -c '
            p="$1"
            while :; do
                if [ -f "$1" ] && ! cmp -s "$1" "$3"; then cp -f "$1" "$2"; exit 0; fi
                [ "$p" = "/" ] && exit 1
                umount -l "$p" 2>/dev/null
                p=$(dirname "$p")
            done
        ' kashi "$_rel" "$KOW/stock.apk" "$_old" 2>/dev/null
        [ -s "$KOW/stock.apk" ] || cp -f "$_rel" "$KOW/stock.apk"
    else
        cp -f "$_rel" "$KOW/stock.apk"
    fi

    kashi_ov_ae d -i "$KOW/stock.apk" -o "$KOW/dec" || { kashi_ov_log "! overlay decode failed"; return 1; }
    _vd=$(find "$KOW/dec" -type d -path '*/res/values' | head -1)
    [ -n "$_vd" ] || { kashi_ov_log "! overlay values not found"; return 1; }
    kashi_ov_set "$_vd" bool config_dozeAlwaysOnDisplayAvailable true
    kashi_ov_set "$_vd" bool config_dozeSupportsAodWallpaper true
    kashi_ov_set "$_vd" bool config_displayBlanksAfterDoze false
    kashi_ov_set "$_vd" string config_dozeComponent "com.android.systemui/com.android.keyguard.doze.MiuiDozeService"

    kashi_ov_ae b -i "$KOW/dec" -o "$KOW/out.apk" || { kashi_ov_log "! overlay build failed"; return 1; }
    unzip -l "$KOW/out.apk" resources.arsc >/dev/null 2>&1 || { kashi_ov_log "! overlay build invalid"; return 1; }
    mkdir -p "$KOM/system/product/overlay"
    cp -f "$KOW/out.apk" "$KOM/system$_rel"
    kashi_ov_log "- DevicesAndroidOverlay patched (AOD enabled)"
    return 0
}
