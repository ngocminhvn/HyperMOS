ui_print "
             __  ___        __  
            /  |/  /__  ___/ /__
           / /|_/ / _ \/ _  (_-<
          /_/  /_/\___/\_,_/___/
            _____         __         
           / ___/__ ___  / /____ ____
          / /__/ -_) _ \/ __/ -_) __/
          \___/\__/_//_/\__/\__/_/   
"

# Check Android version
# Android 14+ users must disable signature verification
android_version=$(getprop ro.build.version.release)
if [ "$android_version" -lt 15 ]; then
    abort "
    Android version is not supported.
    "
elif [ "$android_version" -ge 15 ]; then
    ui_print "
    ------------------------------------------
                     READ!!!                  
     Signature verification must be disabled  
         mandatory for mandatory for stock rom and poco users;      
       otherwise, the module will not work.    
    ------------------------------------------
    "
fi

patch_eu_ext() {
    Ext_PACKAGE_NAME="eu.xiaomi.ext"
    ext_app_path=$(pm path "$Ext_PACKAGE_NAME" | sed 's/package://')
    if ! exist "$ext_app_path"; then
        ui_print "- Hide apps and searchbar provider will not work without XiaomiEuExt apk which is missing in your rom..."
        ui_print "- Proceeding to install it"
        ext_app_path="/product/priv-app/XiaomiEuExt/XiaomiEUExt.apk"

        mkdir -p "$(dirname "$MODPATH/system$ext_app_path")"

        ext_app_path="$MODPATH/system$ext_app_path"
        ui_print "- Copying XiaomiEuExt.apk ..."
        cp -f "$MODPATH/files/ext/XiaomiEUExt.apk" "$ext_app_path"
        ui_print "- Validating XiaomiEuExt.apk..."
        if ! is_valid "$ext_app_path"; then
            ui_print "! Validation failed for XiaomiEuExt"
            ui_print "Skipping to launcher installation...."
        fi
        ui_print "- Done"
    fi
}
# Check if the module is installed in the correct directory
patch_miui() {
    PACKAGE_NAME="com.miui.home"
    ui_print "- Locating Miui Launcher package..."
    pm uninstall-system-updates "$PACKAGE_NAME" 2>/dev/null

    app_path=$(pm path "$PACKAGE_NAME" | sed 's/package://')
    if ! exist "$app_path"; then
        ui_print "- Package not found, adding to a new directory..."
        app_path="/product/priv-app/MiuiHome/MiuiHome.apk"
    fi

    # Ensure the directory for the new app_path exists
    mkdir -p "$(dirname "$MODPATH/system$app_path")"

    app_path="$MODPATH/system$app_path"
    ui_print "- Attempting to install apk directly..."
    pm install -r "$MODPATH/files/MiuiHome.apk" 2>/dev/null
    ui_print "- 2nd phase(ignore if first one failed)..."
    ui_print "- Replacing apk in system..."
    ui_print "- Copying Miui Launcher.apk..."
    cp -f "$MODPATH/files/MiuiHome.apk" "$app_path"
    ui_print "- Validating Miui Launcher.apk..."
    if ! is_valid "$app_path"; then
        abort "! Validation failed for Miui Launcher"
    fi
}

patch_poco() {
    PACKAGE_NAME="com.mi.android.globallauncher"
    ui_print "- Locating Poco Launcher package..."
    pm uninstall-system-updates "$PACKAGE_NAME" 2>/dev/null

    app_path=$(pm path "$PACKAGE_NAME" | sed 's/package://')
    if ! exist "$app_path"; then
        ui_print "- Package not found, adding to a new directory..."
        app_path="/product/priv-app/PocoHome/PocoHome.apk"
    fi
    # Ensure the directory for the new app_path exists
    mkdir -p "$(dirname "$MODPATH/system$app_path")"

    app_path="$MODPATH/system$app_path"
    cp -f "$MODPATH/files/MiuiHome.apk" "$app_path"
    ui_print "- Attempting to install apk directly..."
    pm install -r "$MODPATH/files/MiuiHome.apk" 2>/dev/null
    ui_print "- 2nd phase(ignore if first one failed)..."
    ui_print "- Replacing apk in system..."
    ui_print "- Copying Poco Launcher.apk..."
    ui_print "- Validating Poco Launcher.apk..."
    if ! is_valid "$app_path"; then
        abort "! Validation failed for Poco Launcher"
    fi

}

patch_init() {
    # Patch the init.miui.ext.rc file
    init_file="/system_ext/etc/init/init.miui.ext.rc"
    modified_init="$MODPATH/system/system_ext/etc/init/init.miui.ext.rc"
    ui_print "- Checking for init.miui.ext.rc..."
    if ! exist "$init_file"; then
        ui_print "- init.miui.ext.rc not found in /system_ext/etc/init/"
        abort "! Required file init.miui.ext.rc is missing"
    fi
    # Create the target directory
    mkdir -p "$(dirname "$modified_init")"
    # Copy the original file to the module
    cp -f "$init_file" "$modified_init"
    if ! is_valid "$modified_init"; then
        abort "! Failed to copy init.miui.ext.rc to module"
    fi
    # Modify the copied file
    sed -i 's/com.mi.android.globallauncher/com.miui.home/g' "$modified_init"
    ui_print "- Successfully modified init.miui.ext.rc"
}

delete_cache_files() {
    for file in "$1"/*; do
        if [ -f "$file" ]; then
            echo "$file" | grep -qi "home" && rm -f "$file"
        elif [ -d "$file" ]; then
            delete_cache_files "$file"
        fi
    done
}

clean_environment() {
    ui_print " - Cleaning package cache..."
    base_dir="/data/system/package_cache"
    delete_cache_files "$base_dir"
    ui_print " - Fixing contexts..."
    set_context /system "$MODPATH/system"
    rm -r "$MODPATH/files"
    rm "$MODPATH/customize.sh"
    ui_print "
    ╔══════════════════════════════════════╗
    ║                                      ║
    ║   𝑻𝒉𝒆 𝑳𝒂𝒖𝒏𝒄𝒉𝒆𝒓 𝑴𝒐𝒅 𝑱𝒐𝒖𝒓𝒏𝒆𝒚      ║
    ║             𝑬𝒏𝒅𝒔 𝑯𝒆𝒓𝒆              ║
    ║                                      ║
    ║      Thanks for all your support!    ║
    ║                                      ║
    ╚══════════════════════════════════════╝
"
    ui_print " - Done, reboot your device."
}

# Extract the files from the module
package_extract_dir files "$MODPATH/files"
package_extract_dir system "$MODPATH/system"
# Main script starts here
patch_eu_ext
POCO_PACKAGE="com.mi.android.globallauncher"
if pm path "$POCO_PACKAGE" >/dev/null 2>&1; then
    ui_print "- Poco Launcher found, patching ..."
    patch_poco
    patch_init
else
    ui_print "- Miui Launcher found, patching ..."
    patch_miui
fi
clean_environment
