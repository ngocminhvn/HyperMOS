# TNM HAOTIAN thermal reference configuration files

Raw reference files collected from OS3.0.309.0.WOBCNXM_CN261005 logical partitions.
Collection provenance is retained in repository history before the TNM rename.
Files: 85; partition counts: vendor 20, odm 25, system_ext 10, product 30.

Do NOT directly flash, bind-mount or replace vendor/odm configuration files.
Stock sconfig numbers can differ from PerfHook mode values.
This archive contains configuration data, not executable PerfHook code, a
working kernel governor or a thermal safety bypass.
See manifest.json for original paths and SHA256SUMS.txt for payload hashes.
